package com.boot.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.boot.entity.SubjectEntity;


public interface SubjectRepository extends JpaRepository<SubjectEntity, Integer>
{
       
	
	
}
